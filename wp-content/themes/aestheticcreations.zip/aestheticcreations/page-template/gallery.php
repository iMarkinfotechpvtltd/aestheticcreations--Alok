<?php
/*

 * Template Name: Gallery Page
 
*/

get_header(); 
global $post;
?>
<?php while ( have_posts() ) : the_post(); ?>
    <section class="gallery_view_section">
        <div class="container">
            <h2><?php the_title(); ?></h2>
            <?php the_content(); ?>
            <ul>
			<?php
				$args = array('post_type' => 'gallry','posts_per_page'=>-1,'order'=>'DESC');
				$loop = new WP_Query( $args );
				while ( $loop->have_posts() ) : $loop->the_post(); ?>

			
                <li>
					<?php if ( has_post_thumbnail() ) {
					$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), '' );
					?>
                    <a href="<?php echo $image[0]; ?>" class="fancybox" data-fancybox-group="gallery">
                        <div class="hexagon hexagon2">
                            <div class="hexagon-in1">
                                <div class="hexagon-in2">
								<img src="<?php echo $image[0]; ?>"/>
								<?php
								} else { ?>
								<img src="http://placehold.it/438x348&amp;text=No image found" alt="<?php the_title(); ?>" />
								<?php } ?>  
								
                                </div>
                            </div>
                        </div>
                    </a>
                </li>
				<?php		   
				endwhile;
				wp_reset_query();
				?>
            </ul>
           
        </div>
    </section>
    <section class="video_section">
        <div class="container">
            <h2><?php the_field('radiesse_10_year',$post->ID) ?></h2>
			<div class="video-img">
			<?php $videoID = get_post_meta($post->ID, 'video_link', true); ?>
			<img src="https://img.youtube.com/vi/<?php echo $youtube_video_id = extractUTubeVidId($videoID);?>/0.jpg"/>
			 <a class="video" href="<?php the_field('video_link');?>autoplay=1"><i class="fa fa-play-circle" aria-hidden="true"></i></a>
			</div>

        </div>
    </section>
   

<?php endwhile; wp_reset_query(); ?>

<?php get_footer(); ?>