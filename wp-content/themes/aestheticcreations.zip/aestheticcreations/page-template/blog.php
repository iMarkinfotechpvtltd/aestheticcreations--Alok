<?php
/*

 * Template Name: Blog Page
 
*/

get_header(); 
global $post;
?>
<?php while ( have_posts() ) : the_post(); ?>
    <section class="blogs">
        <div class="container">
            <h2><?php the_title(); ?></h2>
            <?php the_content(); ?>
            <div class="blog_outer">
                <div class="row">
                    <div class="col-md-9">
                        <div class="blog_post">
						<?php
						$args = array('post_type' => 'post','posts_per_page'=>-1,'order'=>'DESC');
						$loop = new WP_Query( $args );
						while ( $loop->have_posts() ) : $loop->the_post(); ?>
                            <div class="cvr">
                                <div class="date1"><?php the_time('d') ?><span><?php the_time('M') ?></span></div>
                                <div class="post_image">
                                    <?php if ( has_post_thumbnail() ) {
									$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'blogimage' );
									?>
									<img src="<?php echo $image[0]; ?>"/>
									<?php
									} else { ?>
									<img src="http://placehold.it/438x348&amp;text=No image found" alt="<?php the_title(); ?>" />
									<?php } ?>  
                                </div>
                                <div class="post_info_dtls">
                                    <h3><?php the_title(); ?></h3>
                                    <ul>
                                        <li><i class="fa fa-calendar"></i><?php the_time('jS F, Y') ?></li>
                                        <li><i class="fa fa-calendar"></i><?php the_time('h : i A') ?></li>
                                        <li><i class="fa fa-user"></i><a href="javascript:void(0)" title="Posts by admin" rel="author"> <?php the_author() ?></a></li>
                                        <li><i class="fa fa-comments" aria-hidden="true"></i><a href="#" rel="category tag">No Comment</a></li>
                                    </ul>
                                    <p><?php  $content = get_the_content(); echo wp_trim_words( $content , '19' ); ?></p>
                                    <a class="rd_more" href="<?php the_permalink(); ?>">read more</a>
                                    <span class="tags"> <i class="fa fa-tags"></i> <?php $tag_ids = wp_get_post_tags( $post->ID, array( 'fields' => 'ids' ) ); ?></span>
                                </div>
                            </div>
                            <?php	
							endwhile;
							wp_reset_query();
							?> 
                            
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="sidebar1">
                            <div class="news-sidebar">

                                <div class="in_sidebar">
                                    <!-- SIDEBAR : begin -->
                                    <form class="search-form" method="get" action="#">
                                        <input class="search-input" value="" name="s" id="s" placeholder="Search" type="text">
                                        <button><i class="fa fa-search" aria-hidden="true"></i></button>
                                    </form>
                                    <h5>Categories</h5>
                                    <ul>
                                        <li class="cat-item cat-item-3"><a href="#">Lorem ipsum dolor</a>
                                        </li>
                                        <li class="cat-item cat-item-4"><a href="#">Lorem ipsum dolor</a>
                                        </li>
                                        <li class="cat-item cat-item-5"><a href="#">Lorem ipsum dolor</a>
                                        </li>
                                        <li class="cat-item cat-item-6"><a href="#">Lorem ipsum dolor</a>
                                        </li>
                                        <li class="cat-item cat-item-7"><a href="#">Lorem ipsum dolor</a>
                                        </li>
                                        <li class="cat-item cat-item-8"><a href="#">Lorem ipsum dolor</a>
                                        </li>
                                        <li class="cat-item cat-item-216"><a href="#">Lorem ipsum dolor</a>
                                        </li>
                                    </ul>
                                    <h5>Latest News</h5>
                                    <ul class="recent-post">
                                        <li>
                                            <div class="media-body">
                                                <a href="#">Lorem ipsum dolor sit amet 2016<span><i class="fa fa-calendar"></i>23 oct, 2016</span></a>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="media-body">
                                                <a href="#">Lorem ipsum dolor sit amet 2016<span><i class="fa fa-calendar"></i>23 oct, 2016</span></a>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="media-body">
                                                <a href="#">Lorem ipsum dolor sit amet 2016<span><i class="fa fa-calendar"></i>23 oct, 2016</span></a>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="media-body">
                                                <a href="#">Lorem ipsum dolor sit amet 2016<span><i class="fa fa-calendar"></i>23 oct, 2016</span></a>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="media-body">
                                                <a href="#">Lorem ipsum dolor sit amet 2016<span><i class="fa fa-calendar"></i>23 oct, 2016</span></a>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="media-body">
                                                <a href="#">Lorem ipsum dolor sit amet 2016<span><i class="fa fa-calendar"></i>23 oct, 2016</span></a>
                                            </div>
                                        </li>

                                    </ul>
                                    <!-- SIDEBAR : end -->
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
   

<?php endwhile; wp_reset_query(); ?>

<?php get_footer(); ?>